import java.text.ParseException;

public class Principal {
    static Thread T = new Thread();

    public static void main(String[] args) throws ParseException {
        Recursos.limparTela();

        int opcaoRegistro = 0;
        String senha = "";
        String confirmaSenha = "";
        String cpfLogin = "";
        boolean senhaConfirmada = false;
        String sLogin = "";
        BancoDeDados bancoDeDados = new BancoDeDados();
        String bgReset = "\u001B[40m";
        String bgRed = "\u001B[41m";

        do {
            try {

                // Recursos.limparTela();
                Recursos.limparTela();
                opcaoRegistro = EntradaSaida
                        .armazenarInt("Informe a ação desejada: \n [1]CADASTRO \n [2]LOGIN \n [3]SAIR");
                cpfLogin = "00000000000";
                Recursos.limparTela();
                switch (opcaoRegistro) {
                    case 1: // Cadastro de conta
                        Usuarios usuario = new Usuarios();
                        usuario.setNomeCompleto(EntradaSaida.cadastrarNome("Informe o primeiro nome", bgRed, bgReset));
                        usuario.setCpf(EntradaSaida.informarCpf("Informe o CPF\n(Somente números)", bgRed, bgReset));
                        usuario.setEmail(EntradaSaida.cadastrarEmail("Informe um email", bgRed, bgReset));
                        usuario.setTelefone(
                                EntradaSaida.cadastrarTelefone("Informe o telefone\n(Somente números)", bgRed,
                                        bgReset));
                        usuario.setDataNascimento(EntradaSaida.cadastrarDataNascimento(
                                "Informe uma data de nascimento\n(somente número)", bgRed, bgReset));

                        usuario.setSexo(EntradaSaida.cadastrarSexo("Informe o seu sexo", bgRed, bgReset));
                        Recursos.limparTela();
                        usuario.setSenha(
                                EntradaSaida.compararSenha(senha, confirmaSenha, senhaConfirmada, bgReset, bgRed));

                        bancoDeDados.adicionarUsuario(usuario);
                        break;
                    case 2: // Login da conta
                        sLogin = "";
                        Recursos.limparTela();
                        int opcaoLogin = 0;
                        boolean validaLogin = false;
                        do {
                            try {

                                cpfLogin = Recursos.formatarCpf(cpfLogin);
                                opcaoLogin = EntradaSaida
                                        .armazenarInt("Informe a ação desejada: \n [1]CPF\n [ " + (cpfLogin)
                                                + " ]\n\n [2]SENHA\n [ " + sLogin
                                                + " ]\n\n [3]CONFIRMAR\n\n [4]VOLTAR");
                                switch (opcaoLogin) {
                                    case 1:

                                        cpfLogin = EntradaSaida.informarCpf("Insira o CPF", bgRed, bgReset);

                                        break;
                                    case 2:
                                        Recursos.limparTela();
                                        sLogin = EntradaSaida.armazenarString("Insira a senha");
                                        Recursos.limparTela();

                                        break;
                                    case 3: // confirmar

                                        validaLogin = EntradaSaida.validarAusenciaLogin(cpfLogin, sLogin, bgRed,
                                                bgReset);
                                        if (validaLogin) {
                                            validaLogin = bancoDeDados.procurarEDefinirUsuario(cpfLogin, sLogin, bgRed,
                                                    bgReset);
                                            if (validaLogin) {
                                                opcaoRegistro = 0;
                                            }
                                        }

                                        break;
                                    case 4: // voltar

                                        break;
                                    default:
                                        EntradaSaida.mostrarMensagemErro(bgRed + "Valor inválido" + bgReset);
                                        break;
                                }
                            } catch (Exception e) {
                                opcaoLogin = 1;
                                Recursos.limparTela();
                            }
                        } while (opcaoLogin <= 3 && opcaoLogin > 0 && validaLogin == false);

                        break;
                    case 3: // Sair

                        break;
                    default:
                        EntradaSaida.mostrarMensagemErro("Valor inválido");
                        break;
                }
            } catch (Exception e) {
                opcaoRegistro = 1;
            }
        } while (opcaoRegistro < 3 && opcaoRegistro > 0);
        int opcaoTelaInicial = 0;
        Recursos.limparTela();
        int opcaoUsuario = 0;
        boolean verifica = true;
        String categoriaSoliticacao = "";
        String solicitacao = "";
        do {
            opcaoUsuario = 0;
            int opcaoTipoSolicitacao = 0;
            int opcaoSolicitacao = 0;
            opcaoTelaInicial = EntradaSaida.escolherOpcaoTelaInicial(bancoDeDados, categoriaSoliticacao, solicitacao);
            switch (opcaoTelaInicial) {
                case 1:
                    EntradaSaida.exibirUsuarioConectado(bancoDeDados);

                    do {
                        opcaoUsuario = EntradaSaida.informarOpcaoUsuario(bancoDeDados);
                        if (opcaoUsuario == 1) {
                            bancoDeDados.retornarHistorico();
                        } else if (opcaoUsuario == 2) {
                            // Sair da conta
                        } else if (opcaoUsuario == 3) {
                            // Excluir conta
                        }
                    } while (opcaoUsuario <= 0 || opcaoUsuario > 4);
                    break;
                case 2:
                    do {
                        try {

                            Recursos.limparTela();
                            opcaoTipoSolicitacao = 0;
                            opcaoTipoSolicitacao = EntradaSaida
                                    .armazenarInt("1-Acidente\n2-Violência\n3-Causas naturais");
                            if (opcaoTipoSolicitacao == 1) {
                                categoriaSoliticacao = "Acidente";
                            } else if (opcaoTipoSolicitacao == 2) {
                                categoriaSoliticacao = "Violência";
                            } else if (opcaoTipoSolicitacao == 3) {
                                categoriaSoliticacao = "Causas Naturais";
                            }
                            solicitacao = "";
                            Recursos.limparTela();
                        }

                        catch (Exception e) {
                            opcaoTipoSolicitacao = 4;
                        }
                    } while (opcaoTipoSolicitacao <= 0 || opcaoTipoSolicitacao > 3);
                    break;
                case 3:

                    Recursos.limparTela();
                    opcaoSolicitacao = 0;
                    String opcoesMenuSolicitacao = "";
                    String[] opcoesSolic = new String[3];

                    if (categoriaSoliticacao.equals("")) {
                        break;
                    } else {
                        do {
                            try {

                                opcoesMenuSolicitacao = EntradaSaida.atribuirSubclasse(opcoesSolic,
                                        categoriaSoliticacao);
                                opcaoSolicitacao = EntradaSaida.armazenarInt(opcoesMenuSolicitacao);
                                if (opcaoSolicitacao <= 0 || opcaoSolicitacao >= 4) {
                                    // Mensagem de erro
                                } else {
                                    solicitacao = opcoesSolic[opcaoSolicitacao - 1];
                                }
                            } catch (Exception e) {
                                Recursos.limparTela();
                                solicitacao = "";
                            }
                        } while (solicitacao == "");
                    }
                    break;
                case 4:
                    int minutos = (int) (Math.random() * (15 - 5 + 1) + 5);
                    int segundos = (int) (Math.random() * (60 - 40 + 1) + 40);

                    Recursos.limparTela();
                    if (solicitacao != "") {
                        HSolicitacao hSolicitacao = new HSolicitacao();
                        hSolicitacao.setMotivoSolicitação(categoriaSoliticacao + "/" + solicitacao);
                        hSolicitacao.setData(EntradaSaida.receberData());
                        hSolicitacao.setHorario(EntradaSaida.receberHorario());
                        hSolicitacao.setStatus("Em andamento");

                        int telaFinal = 0;
                        do {
                            try {

                                EntradaSaida.exibirTelaSolicitacaoConcluida(solicitacao, categoriaSoliticacao, minutos,
                                        segundos);
                                telaFinal = EntradaSaida.armazenarInt("");

                                switch (telaFinal) {
                                    case 1:
                                        // do {

                                        //     segundos -= 40;
                                        //     if (segundos < 1) {
                                        //         minutos -= 1;
                                        //         segundos = 59;
                                        //     }
                                        //     if(segundos<=0){
                                        //         segundos=0;
                                        //     }
                                        //      if(minutos<=0){
                                        //         minutos=0;
                                        //     }
                                        //     Recursos.limparTela();
                                        //     EntradaSaida.exibirTelaSolicitacaoConcluida(solicitacao,
                                        //             categoriaSoliticacao, minutos, segundos);
                                        //     //T.sleep(50);

                                        // } while (minutos != 0 || segundos != 0);
                                        hSolicitacao.setStatus("Finalizado");

                                        bancoDeDados.adicionarHistoricoSolicitacoes(hSolicitacao);

                                        break;
                                    case 2:
                                        hSolicitacao.setStatus("Cancelado");
                                        bancoDeDados.adicionarHistoricoSolicitacoes(hSolicitacao);
                                        break;
                                    default:
                                        break;
                                }
                                
                            } catch (Exception e) {
                                telaFinal = 0;
                            }
                        
                        

                        } while (telaFinal != 1 && telaFinal != 2);
                    }
                    break;
                default:
                    break;

            }
        } while (verifica);
    }
}
