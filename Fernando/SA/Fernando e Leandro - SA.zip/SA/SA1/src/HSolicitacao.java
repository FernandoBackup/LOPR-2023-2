public class HSolicitacao {
    private String horario;
    private String data;
    private String motivoSolicitação;
    private String status;
    
    public String getHorario() {
        return horario;
    }
    public void setHorario(String horario) {
        this.horario = horario;
    }
    public String getData() {
        return data;
    }
    public void setData(String data) {
        this.data = data;
    }
    public String getMotivoSolicitação() {
        return motivoSolicitação;
    }
    public void setMotivoSolicitação(String motivoSolicitação) {
        this.motivoSolicitação = motivoSolicitação;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
}
